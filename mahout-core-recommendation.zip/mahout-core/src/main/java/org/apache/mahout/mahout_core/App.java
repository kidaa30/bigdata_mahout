package org.apache.mahout.mahout_core;

import java.io.File;

import java.io.IOException;
import java.util.List;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.ThresholdUserNeighborhood;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.impl.similarity.TanimotoCoefficientSimilarity;
import org.apache.mahout.cf.taste.impl.similarity.EuclideanDistanceSimilarity;
import org.apache.mahout.cf.taste.impl.similarity.LogLikelihoodSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.UserBasedRecommender;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException , TasteException
    {
        DataModel model = new FileDataModel(new File("music.txt"));
        UserSimilarity similarity = new PearsonCorrelationSimilarity(model);
        UserSimilarity similarity1 = new EuclideanDistanceSimilarity(model);
        UserSimilarity similarity2 = new TanimotoCoefficientSimilarity(model);
        UserSimilarity similarity3 = new LogLikelihoodSimilarity(model);
        
        UserNeighborhood neighborhood = new ThresholdUserNeighborhood(0.1, similarity, model);
        UserNeighborhood neighborhood1 = new ThresholdUserNeighborhood(0.1, similarity1, model);
        UserNeighborhood neighborhood2 = new NearestNUserNeighborhood(1000, similarity2, model);
        UserNeighborhood neighborhood3 = new NearestNUserNeighborhood(1000, similarity3, model);
        UserBasedRecommender recommender = new GenericUserBasedRecommender(model, neighborhood, similarity);
        UserBasedRecommender recommender1 = new GenericUserBasedRecommender(model, neighborhood1, similarity1);
        UserBasedRecommender recommender2 = new GenericUserBasedRecommender(model, neighborhood2, similarity2);
        UserBasedRecommender recommender3 = new GenericUserBasedRecommender(model, neighborhood3, similarity3);
        
        System.out.println("This is the recommendation according to Pearson Correlation Similarity & ThresholdUserNeighborhood:");
        List<RecommendedItem> recommendations = recommender.recommend(3000,2);
        for (RecommendedItem recommendation : recommendations){
        	System.out.println(recommendation);
        }
        
        System.out.println("This is the recommendation according to Euclidean Distance Similarity & ThresholdUserNeighborhood:");
        List<RecommendedItem> recommendations1 = recommender1.recommend(3000,2);
        for (RecommendedItem recommendation : recommendations1){
        	System.out.println(recommendation);
        }
        
        System.out.println("This is the recommendation according to Tanimoto Coefficient Similarity & NearestNUserNeighborhood:");
        List<RecommendedItem> recommendations2 = recommender2.recommend(3000,2);
        for (RecommendedItem recommendation : recommendations2){
        	System.out.println(recommendation);
        }
        System.out.println("This is the recommendation according to Log-Likelihood Similarity & NearestNUserNeighborhood:");
        List<RecommendedItem> recommendations3 = recommender3.recommend(3000,2);
        for (RecommendedItem recommendation : recommendations3){
        	System.out.println(recommendation);
        }
    }
}